import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.decomposition import PCA



def initialize(path= './collect.csv'):

    file = pd.read_csv(path)
    global name_list
    name_list = list(file['Locations'])
    annual_light = list(file['ANL'].astype(int))
    annual_light = positivization(annual_light, mode='1')

    airpollution_list = list(file['PM'].astype(float))
    airpollution_list = positivization(airpollution_list)

    population_list = list(file['POP'].astype(int))
    population_list = positivization(population_list, mode='0', toOne='minmax')
    

    GDP_list = list(file['GDP'].astype(str))
    new = []
    for i in GDP_list:
        i = i.replace(',','')
        new.append(int(i))
    GDP_list = positivization(new)

    temp_list = list(file['TMP'].astype(str))
    low_list, high_list = [], []
    for tem_tuple in temp_list:
        tem_tuple = tem_tuple.replace('（','')
        tem_tuple = tem_tuple.replace('）','')
        tem_tuple = tem_tuple.split('，')
        low_list.append(int(tem_tuple[0]))
        high_list.append(int(tem_tuple[1]))   
    low_list = positivization(low_list, mode='3', ifStd=False)
    high_list = positivization(high_list, mode='3', ifStd=False)
    new = []
    for k in range(len(low_list)):
        new.append(low_list[k]+high_list[k])
    temp_list = positivization(new)

    rain_list = list(file['ARF'].astype(int))
    rain_list = positivization(rain_list, mode='2', best_cir= int(sum(rain_list)/len(rain_list)))

    electric_list = list(file['REC'].astype(int))
    electric_list = positivization(electric_list)

    skyglow_list = list(file['skyglow'].astype(int))
    skyglow_list = positivization(skyglow_list)

    return annual_light, airpollution_list, population_list, GDP_list, temp_list, rain_list, electric_list, skyglow_list

def positivization(input, mode = '0', best_cir=0, a=2, b=25, ifStd = True, toOne = 'minmax'):

    new = []
    if mode == '1':
        for i in input:
            new.append(1/i)
    
    if mode == '2':
        X = 0
        for i in input:
            t = abs(i - best_cir)
            if t > X:
                X = t
        for data in input:
            new.append(1 - abs(data - best_cir)/X)
    
    if mode == '3':
        for data in input:
            new.append(math.sqrt(pow(data - a, 2)+pow(data-b, 2)))

    # standardlize it only
    if mode == '0':
        new = input
    
    # normalization
    new = preprocessing.scale(new)
    if ifStd:
        # choose different strategies to standardlize  
        if toOne == 'minmax':
            new = preprocessing.minmax_scale(new)
        elif toOne == 'maxabs':
            new = preprocessing.maxabs_scale(new)
        elif toOne == 'roubust':
            new = preprocessing.robust_scale(new)
        else:
            print(f'Method {toOne} set no included!')
    
    return new

def distanceCal(input, eps = 1e-8, aug_pos = 7, alpha = 2):
    
    M,L = input.shape
    # M stands for the num of dimensions of our data
    P = np.zeros(shape=input.shape)
    
    # to calculate the projection matrix P
    for i in range(M):
        for j in range(L):
            P[i,j] = input[i,j]/sum(input[i,:])
    
    # for each criterion
    entropy_list = []
    for i in range(M):
        sum_num = 0
        for j in range(L):
            sum_num += math.log(P[i,j] + eps) * P[i,j]

        entropy = -1*(1/math.log(M))*sum_num
        entropy_list.append(entropy)

    # to estimate the degree of divergence for each dimension
    div_list = list(1 - x for x in entropy_list)

    # Output the weight for our model
    weight_list = []
    for i in range(M):
        weight_list.append(div_list[i]/sum(div_list))
        if i == aug_pos:
            weight_list[i] = weight_list[i]*alpha
    return weight_list

def TOPSIS(input, weight_list, correction_indx = [5]):

    M,N = input.shape
    # creating a decision making metrix R
    R = np.zeros(shape=input.shape)
    for i in range(M):
        sum_num = 0
        for j in range(N):
            sum_num += pow(input[i,j], 2)

        for j in range(N):
            R[i,j] = input[i,j]/math.sqrt(sum_num)
    
    # to evaluate with the relative weight
    value = R.copy()
    for i in range(M):
        for j in range(N):
            value[i,j] = weight_list[i]*R[i,j]
    
    # evaluate PIS and NIS array with manual correction
    PISNIS = []
    for i in range(M):
        Sscore = 0
        if i in correction_indx:
            vj = min(value[i,:])
        else:
            vj = max(value[i,:])
        
        for j in range(N):
            Sscore += pow(value[i,j] - vj,2)
        
        PISNIS.append(math.sqrt(Sscore))
    
    # Calculate the closeness of the optimize value we suppose
    dis_arr = []
    for i in range(len(PISNIS)):
        dis_arr.append(PISNIS[i]/sum(PISNIS))
    
    return dis_arr

def corrCal(input):
    
    for i in range(input.shape[0]):
        feature = input[i,:]


def map2level(data_arr, weight_list, name_list, save_path = './testscore.xlsx'):

    predict_list = []
    for idx in range(len(name_list)):
        predict = 0
        name = name_list[idx]
        feature = data_arr[:,idx]

        for j in range(len(feature)):
            predict += feature[j]*weight_list[j]

        # print(f'Name: {name}   \npredict score:{predict:4f}\n')
        predict_list.append(predict)
    
    score_list = []
    # map the score to 0-10 level
    for i in range(len(predict_list)):
        score = int(10*predict_list[i])
        score_list.append(score)
        print(f'Name: {name_list[i]}   \npredict score:{score}\n')

    data = list([name_list, predict_list, score_list])
    df = pd.DataFrame({'location':name_list, 'original score':predict_list, 'level':score_list})
    df.to_csv(save_path, mode='a+') 
    

def pca_scoring(data_matrix, name_list, plot_path='./pca_model1_plot.png'):
    """
    Perform PCA and generate a 2D scatter plot for visualization.
    Does not save a CSV of scores.
    """
    # Step 1: Perform PCA (2 components for visualization)
    pca = PCA(n_components=2)
    principal_components = pca.fit_transform(data_matrix.T)  # shape: (N locations, 2)

    # Step 2: Get 1D score from PC1
    pc1_scores = principal_components[:, 0]
    normalized_scores = preprocessing.minmax_scale(pc1_scores) * 10
    levels = normalized_scores.astype(int)

    # Step 3: Create PCA scatter plot
    plt.figure(figsize=(8, 6))
    plt.scatter(principal_components[:, 0], principal_components[:, 1], c=normalized_scores, cmap='viridis', s=50)
    for i, name in enumerate(name_list):
        plt.text(principal_components[i, 0] + 0.01, principal_components[i, 1] + 0.01, name, fontsize=8)

    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 2')
    plt.title('PCA Scatter Plot for Model 1')
    plt.colorbar(label='Normalized PC1 Score (0–10)')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(plot_path)
    plt.close()
    print("PCA plot saved to", plot_path)


if __name__ == '__main__':

    all = np.array(initialize())
    weight = distanceCal(all)
    dis_weight = TOPSIS(all, weight)
    print(dis_weight)
    np.save('old_weight.npy',dis_weight)
    map2level(all, dis_weight, name_list)
    pca_scoring(all, name_list, plot_path='./pca_model1_plot.png')
