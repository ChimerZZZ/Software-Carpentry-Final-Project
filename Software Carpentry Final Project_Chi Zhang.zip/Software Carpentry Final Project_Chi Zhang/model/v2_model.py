from v1_model import *
import pandas as pd
import numpy as np
import math
import sys
from scipy.stats import pearsonr
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn import preprocessing


def data_preprocess(path= './collect.csv'):

    # load the data from csv file and wash them
    file = pd.read_csv(path)
    global name_list
    name_list = list(file['Locations'])
    annual_light = list(file['ANL'].astype(int))
    annual_light = positivization(annual_light, mode='1')

    airpollution_list = list(file['PM'].astype(float))
    airpollution_list = positivization(airpollution_list)

    population_list = list(file['POP'].astype(int))
    population_list = positivization(population_list, mode='0', toOne='minmax')
    

    GDP_list = list(file['GDP'].astype(str))
    new = []
    for i in GDP_list:
        i = i.replace(',','')
        new.append(int(i))
    GDP_list = positivization(new)

    temp_list = list(file['TMP'].astype(str))
    low_list, high_list = [], []
    for tem_tuple in temp_list:
        tem_tuple = tem_tuple.replace('（','')
        tem_tuple = tem_tuple.replace('）','')
        tem_tuple = tem_tuple.split('，')
        low_list.append(int(tem_tuple[0]))
        high_list.append(int(tem_tuple[1]))   
    low_list = positivization(low_list, mode='3', ifStd=False)
    high_list = positivization(high_list, mode='3', ifStd=False)
    new = []
    for k in range(len(low_list)):
        new.append(low_list[k]+high_list[k])
    temp_list = positivization(new)

    rain_list = list(file['ARF'].astype(int))
    rain_list = positivization(rain_list, mode='2', best_cir= int(sum(rain_list)/len(rain_list)))

    electric_list = list(file['REC'].astype(int))
    electric_list = positivization(electric_list)

    skyglow_list = list(file['skyglow'].astype(int))
    skyglow_list = positivization(skyglow_list)

    UL_intensity_list = list(file['ULI'].astype(float))
    UL_intensity_list = positivization(UL_intensity_list)

    std_list = list(file['STD'].astype(float))
    std_list = positivization(std_list)

    clutter_list = list(file['CLI'].astype(float))
    clutter_list = positivization(clutter_list)

    knum_list = list(file['CNB'].astype(int))
    knum_list = positivization(knum_list)

    Unit_light_intensity_list = dataCorrection(
        target= UL_intensity_list,
        input= [annual_light, airpollution_list, temp_list, rain_list, skyglow_list]
    )

    Development_list = dataCorrection(
        target= GDP_list,
        input= [population_list, electric_list]
    )

    Clutter_list = dataCorrection(
        target= clutter_list,
        input=[std_list, knum_list]
    )

    return Unit_light_intensity_list, Development_list, Clutter_list

    
def dataCorrection(target, input, mode = 'normalize'):
    
    # solving for the corrected data series
    output = target.copy()
    for input_sequence in input:
        pccs = pearsonr(target, input_sequence)
        alpha = pccs[0]
        output = list(map(lambda x :x[0]+x[1]*alpha ,zip(output, input_sequence)))
    
    # define if it is necessary to normalize the data (data washing button)
    if mode == 'normalize':
        output = positivization(output)
    return output


if __name__ == '__main__':
        
    data_matrix = np.array(data_preprocess('./collect.csv'))
    weight = distanceCal(data_matrix, aug_pos=-1)
    dis_weight = TOPSIS(data_matrix, weight)

    # np.save('weight.npy', np.array(dis_weight))

    map2level(data_matrix, dis_weight, name_list, save_path='./score.csv')
    
    # PCA on the 3 refined indicators
    pca = PCA(n_components=2)
    data_T = data_matrix.T  # shape: (num_locations, 3)
    pca_components = pca.fit_transform(data_T)

    # Normalize PC1 for coloring
    pc1 = pca_components[:, 0]
    pc1_norm = preprocessing.minmax_scale(pc1) * 10

    plt.figure(figsize=(8, 6))
    plt.scatter(pca_components[:, 0], pca_components[:, 1], c=pc1_norm, cmap='viridis', s=50)
    for i, name in enumerate(name_list):
        plt.text(pca_components[i, 0] + 0.01, pca_components[i, 1] + 0.01, name, fontsize=8)
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.title("PCA Scatter Plot for Model 2 (3 Refined Indicators)")
    plt.colorbar(label="Normalized PC1 Score (0–10)")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('./pca_model2_plot.png')
    plt.close()
    print("Model 2 PCA plot saved as './pca_model2_plot.png'")


    
    