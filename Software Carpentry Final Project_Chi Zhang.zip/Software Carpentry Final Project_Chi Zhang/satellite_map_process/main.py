import cv2
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import os
import csv

from sklearn.cluster import DBSCAN, KMeans
from sklearn.metrics import silhouette_score

def analyzerFig(fig, thes= 245, method= 'kmeans', name=''):
    
    H,L = fig.shape
    pixel_count = H*L

    # count the relavant scores of the map
    sum = np.mean(fig)
    average_light = sum
    std_score = fig.std()
    print(f'Total Area: {pixel_count}  average light: {average_light:4f} variance: {std_score:4f}')
    bound = 40
    if average_light < 50:
        thes = 200
        bound = 20
    if average_light < 5:
        thes = 100
        bound = 15
        
    # binarize the map according to the theshold we set
    ret, bifig = cv2.threshold(fig, thes, 255, cv2.THRESH_BINARY)
    clutter_score = bifig.sum()/255
    

    # clustering the light source from the binary map
    light_indices = []
    for i in range(H):
        for j in range(L):
            if bifig[i][j] > 0:
                light_indices.append(np.array([i,j]))

    light_indices = np.array(light_indices, dtype=np.int64)
    if average_light > 80:
        method = 'dbscan'

    # apply the DBSCAN method (for big cities)
    if method == 'dbscan':
        db = DBSCAN(eps=5, min_samples=2).fit(light_indices)
        
        plt.figure()
        plt.scatter(light_indices[:,1], light_indices[:,0], s=5, c=db.labels_)
        plt.savefig('result/' + name +'.png')
        score_list = [name, average_light, std_score, clutter_score/pixel_count, 1]
        return score_list

    # apply the K-means method (for metropolitian / rural areas)
    if method == 'kmeans':
        scores = []
        for k in tqdm(range(2, bound)):
            label = KMeans(k, random_state=0).fit_predict(light_indices)
            scores.append(silhouette_score(light_indices,label))
        plt.figure()
        plt.subplot(2,1,1)
        plt.xlabel('K')
        plt.plot(scores, c='r', label='Total inter-cluster distances')
        plt.legend()
        

        best_k = 1 + scores.index(max(scores))
        label = KMeans(best_k, random_state=0).fit_predict(light_indices)
        plt.subplot(2,1,2)
        plt.scatter(light_indices[:,1], light_indices[:,0], s=5, c=label)
        plt.savefig('result/' + name +'.png')
    
        cluster = best_k

        score_list = [name, average_light, std_score, clutter_score/pixel_count, cluster]
        return score_list

def readImg(path = './data'):
    files= os.listdir(path) 
    # read the satellite maps collected
    fig_list, name_list = [],[]
    for file in files:
        name = file.replace('.png','')
        
        try:
            fig = cv2.imread(path+'/'+file)[:,:,2]
        except:
            continue
            raise UserWarning
            
        fig_list.append(fig)
        name_list.append(name)

    return fig_list, name_list

if __name__ == '__main__':

    # extract the red channel
    figs,names = readImg()
    header = ['name', 'average_light', 'std score', 'clutter score', 'cluster number']
    with open('result.csv', 'w') as f:
        writer = csv.writer(f)
        writer.writerow(header)

    for i in range(len(figs)):
        fig, name = figs[i], names[i]
        # analyze the fig
        print(f'Processing {name}')
        score = analyzerFig(fig, thes=250, method='kmeans', name=name)
        with open('result.csv', 'a+') as f:
            writer = csv.writer(f)
            writer.writerow(score)
    
